// Intentionally minimal: no auto-redirects, popups, fake verification, download triggers or content lockers.
document.documentElement.classList.add('js-ready');
